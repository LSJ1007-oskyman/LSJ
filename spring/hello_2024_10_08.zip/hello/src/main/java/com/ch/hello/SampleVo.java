package com.ch.hello;

public class SampleVo {
	private Integer mno;
	private String firstName;
	private String lastName;

	public Integer getMno() {
		return mno;
	}

	public void setMno(Integer mno) {
		this.mno = mno;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/*
	 * public String toString() { return
	 * "SampleVosuper[나이:"+mno+", 성:"+firstName+ ", 이름:"+lastName+"]"; }
	 */
}